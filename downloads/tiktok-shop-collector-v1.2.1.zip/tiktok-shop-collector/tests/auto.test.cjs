const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {JSDOM}=require('jsdom');
const Export=require('../exporter.js'),ExcelJS=require('exceljs');
function collection({stopAt=0,limited=false,autoExport=true,morePages=0,brokenMore=false}={}) {
  const state={},messages=[];let listener,frame=0,ticks=0,extra=0,clicks=0;
  const el={scrollHeight:1000};
  const context={crypto:{randomUUID:()=> 'run-1'},document:{},location:{href:'https://shop.tiktok.com/th/c/pots/1'},
    chrome:{storage:{local:{set:async value=>Object.assign(state,value)}},runtime:{onMessage:{addListener:f=>listener=f},sendMessage:async m=>{messages.push(m);return {ok:true};}}},
    ShopExtractor:{extract:()=>Array.from({length:Math.min(frame+1,3)+extra},(_,i)=>({name:'Pot '+i,url:'https://shop.tiktok.com/th/view/product/'+i}))},
    ShopScroller:{target:()=>el,step:()=>{if(frame<2){frame++;return true;}return false;},atEnd:()=>frame>=2,findMore:()=>frame>=2 && (brokenMore || extra<morePages) ? {disabled:false,element:{click(){clicks++;if(!brokenMore)extra++;}}} : null},
    setTimeout:fn=>{ticks++;if(stopAt&&ticks===stopAt)listener({type:'STOP'},null,()=>{});queueMicrotask(fn);}
  };
  vm.createContext(context);vm.runInContext(fs.readFileSync(require.resolve('../content.js'),'utf8'),context);
  listener({type:'COLLECT',auto:true,untilEnd:!limited,limit:2,autoExport,format:'csv'},null,()=>{});
  return {state,messages,clicks:()=>clicks,done:async()=>{for(let i=0;i<1000&&state.collecting!==false;i++)await new Promise(r=>setImmediate(r));assert.equal(state.collecting,false);}};
}
test('collection scrolls through new products, waits at end, then exports exactly once',async()=>{
 const c=collection();await c.done();assert.equal(c.state.products.length,3);assert.equal(c.messages.length,1);assert.equal(c.messages[0].products.length,3);assert.match(c.state.collectStatus,/ท้ายรายการ/);
});
test('manual Stop retains rows without automatically downloading',async()=>{
 const c=collection({stopAt:1});await c.done();assert.equal(c.messages.length,0);assert.ok(c.state.products.length>0);assert.match(c.state.collectStatus,/หยุดโดยผู้ใช้/);
});
test('configured item limit exports only the selected count',async()=>{
 const c=collection({limited:true});await c.done();assert.equal(c.state.products.length,2);assert.equal(c.messages[0].products.length,2);assert.match(c.state.collectStatus,/ครบจำนวน/);
});
test('automatic download can be disabled',async()=>{const c=collection({autoExport:false});await c.done();assert.equal(c.messages.length,0);});
test('scroller selects the product scrollbar and detects its bottom',()=>{
 const dom=new JSDOM('<div id="pane" style="overflow-y:auto"><a href="/th/view/product/1">Pot</a></div>',{url:'https://shop.tiktok.com/th/c/pots/1'});
 const w=dom.window;w.ShopExtractor=require('../extractor.js');w.eval;const el=w.document.getElementById('pane');
 Object.defineProperties(el,{scrollHeight:{value:2000},clientHeight:{value:500}});
 el.scrollTo=({top})=>{el.scrollTop=Math.min(1500,top);};
 const ctx={ShopExtractor:w.ShopExtractor,module:{exports:{}}};vm.createContext(ctx);vm.runInContext(fs.readFileSync(require.resolve('../scroller.js'),'utf8'),ctx);
 const s=ctx.ShopScroller;assert.equal(s.target(w.document),el);assert.equal(s.atEnd(el),false);s.step(el);assert.equal(el.scrollTop,400);el.scrollTop=1500;assert.equal(s.atEnd(el),true);dom.window.close();
});
function worker(fail=false){
 const state={},downloads=[];let listener;
 const context={importScripts(){},ShopExport:Export,ExcelJS,TextEncoder,btoa:text=>Buffer.from(text,'binary').toString('base64'),
 chrome:{runtime:{onMessage:{addListener:f=>listener=f}},storage:{local:{get:async()=>state,set:async value=>Object.assign(state,value)}},downloads:{download:async options=>{if(fail)throw new Error('disabled');downloads.push(options);return 42;},onChanged:{addListener(){}}}}};
 vm.createContext(context);vm.runInContext(fs.readFileSync(require.resolve('../background.js'),'utf8'),context);
 return {state,downloads,send:(format='csv')=>new Promise(resolve=>listener({type:'AUTO_EXPORT',runId:'run-id',format,products:[{name:'กระถาง',url:'https://shop.tiktok.com/th/view/product/1'}]},{tab:{url:'https://shop.tiktok.com/th/c/pots/1'}},resolve))};
}
test('worker exports CSV without popup, suppressing repeat completion messages',async()=>{
 const w=worker();assert.equal((await w.send()).ok,true);assert.equal((await w.send()).ok,true);assert.equal(w.downloads.length,1);assert.equal(w.downloads[0].saveAs,false);
 assert.match(Buffer.from(w.downloads[0].url.split(',')[1],'base64').toString('utf8'),/กระถาง/);
});
test('worker exports a real Excel workbook',async()=>{
 const w=worker();assert.equal((await w.send('xlsx')).ok,true);const bytes=Buffer.from(w.downloads[0].url.split(',')[1],'base64');const book=new ExcelJS.Workbook();await book.xlsx.load(bytes);assert.equal(book.getWorksheet(1).getCell('B2').value,'กระถาง');
});
test('failed automatic downloads keep data available and report a retry path',async()=>{const w=worker(true);assert.equal((await w.send()).ok,false);assert.match(w.state.exportStatus,/กดดาวน์โหลดเองได้/);});

test('View more is clicked repeatedly for new pages before automatic export',async()=>{
 const c=collection({morePages:2});await c.done();assert.equal(c.clicks(),2);assert.equal(c.messages.length,1);assert.equal(c.messages[0].products.length,5);assert.match(c.state.collectStatus,/ท้ายรายการ/);
});
test('a stuck View more is retried at most twice and reported as incomplete',async()=>{
 const c=collection({brokenMore:true});await c.done();assert.equal(c.clicks(),2);assert.match(c.state.collectStatus,/View more.*ยังไม่ครบ/);assert.equal(c.messages.length,1);
});
test('View more selector accepts list expansion but rejects navigation, product text, hidden and disabled controls',()=>{
 const dom=new JSDOM(`<header><button>View more</button></header><main><section><a href="/th/view/product/1"><span>View more</span></a><a href="/th/view/product/2">Pot</a><button style="display:none">View more</button><a href="/th/c/other">View more</a><button id="more">View more</button></section></main>`,{url:'https://shop.tiktok.com/th/c/pots/1'});
 const w=dom.window;for(const el of w.document.querySelectorAll('*'))el.getBoundingClientRect=()=>({width:100,height:20,top:el.tagName==='A'&&el.getAttribute('href').includes('product')?100:200,bottom:el.tagName==='A'&&el.getAttribute('href').includes('product')?120:220});
 const ctx={ShopExtractor:require('../extractor.js')};vm.createContext(ctx);vm.runInContext(fs.readFileSync(require.resolve('../scroller.js'),'utf8'),ctx);
 const button=w.document.getElementById('more');assert.equal(ctx.ShopScroller.findMore(w.document,w.document.documentElement).element,button);
 button.disabled=true;assert.equal(ctx.ShopScroller.findMore(w.document,w.document.documentElement).disabled,true);
 button.textContent='ดูเพิ่มเติม';assert.equal(ctx.ShopScroller.findMore(w.document,w.document.documentElement).element,button);
 button.remove();assert.equal(ctx.ShopScroller.findMore(w.document,w.document.documentElement),null);dom.window.close();
});
