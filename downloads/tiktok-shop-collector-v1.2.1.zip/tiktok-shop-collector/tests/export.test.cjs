const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {JSDOM}=require('jsdom');
const ExcelJS=require('exceljs');
const Export=require('../exporter.js');
const products=[{name:'กระถาง "ดินเผา", เล็ก\nสีส้ม',price:'฿129.50',sales:'ขายแล้ว 1.2K',image:'https://cdn.example/pot.jpg',url:'https://shop.tiktok.com/th/view/product/123',source:'https://shop.tiktok.com/th/c/pots/1',collectedAt:'2026-10-24T06:00:00Z'},{name:'=HYPERLINK("https://evil.test")',price:'',sales:'',image:'javascript:alert(1)',url:'https://shop.tiktok.com/th/view/product/456'}];
test('CSV preserves Thai, quotes, commas, line breaks and missing values',()=>{
  const csv=Export.csv(products);
  assert.ok(csv.startsWith('\uFEFF'));assert.ok(csv.includes('"กระถาง ""ดินเผา"", เล็ก\nสีส้ม"'));
  assert.ok(csv.includes('"฿129.50","ขายแล้ว 1.2K"'));assert.ok(csv.endsWith('\r\n'));
  assert.ok(csv.includes('"URL ภาพ"'));assert.ok(!csv.includes('javascript:'));
});
test('CSV protects against formula injection, including whitespace prefixes',()=>{
  for(const name of ['=1+1','+cmd','-cmd','@SUM(A1)','\t=IMPORTXML("url")','\n+cmd']) {
    const csv=Export.csv([{name}]);assert.ok(csv.includes('"\''+name.replace(/"/g,'""')+'"'));
  }
});
test('real XLSX round trip preserves text, formatting, URLs and generated image formula',async()=>{
  const book=Export.workbook(products,ExcelJS);const data=await book.xlsx.writeBuffer();
  assert.equal(Buffer.from(data).subarray(0,2).toString(),'PK');
  const read=new ExcelJS.Workbook();await read.xlsx.load(data);
  const s=read.getWorksheet('TikTok Products');assert.equal(s.rowCount,3);assert.equal(s.getCell('B2').value,products[0].name);
  assert.equal(s.getCell('C2').value,'฿129.50');assert.equal(s.getCell('D2').value,'ขายแล้ว 1.2K');
  assert.equal(s.getCell('B3').type,ExcelJS.ValueType.String);assert.equal(s.getCell('B3').value,products[1].name);
  assert.equal(s.getCell('E2').value.hyperlink,products[0].image);assert.equal(s.getCell('E3').value,'');
  assert.match(s.getCell('A2').value.formula,/_xlfn\.IMAGE\(E2/);
  assert.equal(s.views[0].ySplit,1);assert.equal(s.getRow(2).height,72);assert.equal(s.getColumn(2).width,48);
});
test('empty exports have headers and no phantom product rows',()=>{
  assert.equal(Export.workbook([],ExcelJS).getWorksheet(1).rowCount,1);
  assert.equal(Export.csv([]).split('\r\n').length,2);
});
test('browser bundle loads locally and popup export controls use collected data',async()=>{
  const dom=new JSDOM(fs.readFileSync(require.resolve('../popup.html'),'utf8'),{runScripts:'outside-only',url:'https://extension.local/popup.html'});
  const w=dom.window;
  const state={products,collectStatus:'เก็บเสร็จ'};
  w.chrome={storage:{local:{get:async()=>state,remove:async()=>{}},onChanged:{addListener(){}}}};
  w.eval(fs.readFileSync(require.resolve('../vendor/exceljs.min.js'),'utf8'));
  w.eval(fs.readFileSync(require.resolve('../exporter.js'),'utf8'));
  w.eval(fs.readFileSync(require.resolve('../popup.js'),'utf8'));
  await new Promise(resolve=>setTimeout(resolve,10));
  assert.equal(typeof w.ExcelJS.Workbook,'function');
  assert.equal(w.document.getElementById('count').textContent,'2 รายการ');
  assert.equal(w.document.getElementById('csv').disabled,false);assert.equal(w.document.getElementById('excel').disabled,false);
  const calls=[];w.ShopExport.download=(...args)=>calls.push(args);
  w.document.getElementById('csv').click();await new Promise(resolve=>setTimeout(resolve,10));
  assert.equal(calls.length,1);assert.match(calls[0][2],/\.csv$/);assert.ok(calls[0][0].startsWith('\uFEFF'));
  dom.window.close();
});
