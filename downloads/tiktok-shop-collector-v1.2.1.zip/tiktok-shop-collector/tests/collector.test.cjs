const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const {JSDOM}=require('jsdom');
const {fields,productUrl,extract}=require('../extractor.js');
const base='https://shop.tiktok.com/th/c/garden-pots-planters/900232';
test('Thai/English visible price and sold labels are preserved',()=>{
  assert.deepEqual(fields('กระถาง ฿129.50 ขายแล้ว 1.2K'),{price:'฿129.50',sales:'ขายแล้ว 1.2K'});
  assert.deepEqual(fields('Pot THB 1,299 2.3K sold'),{price:'THB 1,299',sales:'2.3K sold'});
  assert.deepEqual(fields('ยังไม่มีข้อมูล'),{price:'',sales:''});
  assert.equal(fields('฿20 – ฿50 ขายแล้ว 2 หมื่น').price,'฿20 – ฿50');
});
test('only HTTPS TikTok product links qualify and tracking is stripped',()=>{
  assert.equal(productUrl('/th/view/product/123?x=1',base),'https://shop.tiktok.com/th/view/product/123');
  for(const url of ['https://tiktok.com.evil.test/product/1','javascript:alert(1)','https://shop.tiktok.com/th/c/pots/1']) assert.equal(productUrl(url,base),'');
});
test('separate cards stay separate, duplicate links merge, missing sales stays blank',()=>{
  const dom=new JSDOM(`<main>
  <article><a href="/th/view/product/123?tracking=1"><img src="https://cdn.example/pot.jpg" alt="กระถางดินเผา"></a><h3>กระถางดินเผา</h3><p>฿129</p><p>ขายแล้ว 1.2K</p><a href="/th/view/product/123?tracking=2">ดูสินค้า</a></article>
  <article><a href="/th/view/product/456"><img src="https://cdn.example/planter.jpg" alt="กระถางพลาสติก"></a><h3>กระถางพลาสติก</h3><p>฿59</p></article>
  <a href="/th/c/ads/99">โฆษณา</a></main>`,{url:base});
  const rows=extract(dom.window.document,base);
  assert.equal(rows.length,2);
  assert.equal(rows[0].name,'กระถางดินเผา'); assert.equal(rows[0].price,'฿129');
  assert.equal(rows[0].sales,'ขายแล้ว 1.2K'); assert.equal(rows[1].sales,'');
  assert.equal(rows[1].price,'฿59'); assert.equal(rows[0].image,'https://cdn.example/pot.jpg');
});
