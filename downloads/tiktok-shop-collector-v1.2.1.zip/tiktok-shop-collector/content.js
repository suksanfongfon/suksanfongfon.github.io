(() => {
  if (globalThis.shopCollectorInstalled) return;
  globalThis.shopCollectorInstalled = true;
  let running = false, stop = false;
  async function collect(options) {
    if (running) throw new Error('กำลังเก็บข้อมูลอยู่');
    running=true; stop=false;
    const limit=options.untilEnd ? Infinity : options.limit;
    const runId=crypto.randomUUID(), rows=new Map();
    let reason='เก็บหน้าปัจจุบันแล้ว';
    const merge=async()=>{
      for(const row of ShopExtractor.extract(document,location.href)) {
        if(rows.size>=limit && !rows.has(row.url)) continue;
        const prev=rows.get(row.url);
        rows.set(row.url,prev ? {...prev,...Object.fromEntries(Object.entries(row).filter(([,v])=>v!==''))} : row);
      }
      await chrome.storage.local.set({products:[...rows.values()],collectStatus:`กำลังเก็บ · ${rows.size} รายการ`,collecting:true});
    };
    try {
      await chrome.storage.local.set({exportStatus:''});
      await merge();
      let idleEnd=0, stalled=0, round=0, moreWaiting=0;
      const moreAttempts=new Map();
      while(options.auto && !stop && rows.size<limit) {
        const before=rows.size, el=ShopScroller.target(document), oldHeight=el.scrollHeight;
        const moved=ShopScroller.step(el);
        // Give lazy-loaded products time to appear, checking Stop every 200ms.
        for(let i=0;i<10 && !stop;i++) await new Promise(r=>setTimeout(r,200));
        await merge();
        if(stop || rows.size>=limit) break;
        const current=ShopScroller.target(document);
        const more=ShopScroller.findMore(document,current);
        round++;
        if(more) {
          const key=rows.size+':'+[...rows.keys()].slice(-1)[0];
          const attempt=moreAttempts.get(key) || {count:0,round:-10};
          if(!more.disabled && attempt.count<2 && round-attempt.round>=4) {
            more.element.click();
            moreAttempts.set(key,{count:attempt.count+1,round});
            idleEnd=0;stalled=0;moreWaiting=0;
            await chrome.storage.local.set({collectStatus:`กด View more แล้ว — รอโหลดสินค้าเพิ่ม · ${rows.size} รายการ`});
            continue;
          }
          moreWaiting++;
          if(moreWaiting>=15) {reason='ปุ่ม View more ไม่โหลดสินค้าเพิ่ม — ข้อมูลอาจยังไม่ครบ';break;}
          // An expansion/loading control still exists; do not declare the list complete.
          idleEnd=0;stalled=0;
          continue;
        }
        moreWaiting=0;
        const stable=rows.size===before && current.scrollHeight===oldHeight;
        idleEnd=stable && ShopScroller.atEnd(current) ? idleEnd+1 : 0;
        stalled=stable && !moved && !ShopScroller.atEnd(current) ? stalled+1 : 0;
        if(idleEnd>=6) {reason='ถึงท้ายรายการแล้ว — ไม่พบสินค้าเพิ่ม 12 วินาที';break;}
        if(stalled>=6) {reason='เลื่อนต่อไม่ได้ — ข้อมูลอาจยังไม่ครบ';break;}
      }
      if(rows.size>=limit) reason='ครบจำนวนที่ตั้งไว้';
      if(stop) reason='หยุดโดยผู้ใช้';
      await chrome.storage.local.set({collectStatus:`${reason} · ${rows.size} รายการ${rows.size ? '' : ' — ไม่พบการ์ดสินค้า กรุณาตรวจหน้าเว็บ'}`});
      if(options.autoExport && !stop && rows.size) {
        const result=await chrome.runtime.sendMessage({type:'AUTO_EXPORT',runId,format:options.format,products:[...rows.values()]});
        if(!result?.ok) throw new Error(result?.error || 'ดาวน์โหลดอัตโนมัติไม่สำเร็จ กดดาวน์โหลดเองได้');
      }
    } finally {running=false;await chrome.storage.local.set({collecting:false});}
  }
  chrome.runtime.onMessage.addListener((m,sender,reply)=>{
    if(m.type==='COLLECT') {
      if(running) {reply({ok:false,error:'กำลังเก็บข้อมูลอยู่'});return;}
      const limit=Number(m.limit);
      if(m.untilEnd!==true && (!Number.isInteger(limit)||limit<1||limit>10000)) {reply({ok:false,error:'จำนวนต้องอยู่ระหว่าง 1–10000'});return;}
      reply({ok:true});
      collect({auto:m.auto===true,untilEnd:m.untilEnd===true,limit,autoExport:m.autoExport===true,format:m.format==='xlsx'?'xlsx':'csv'})
        .catch(async e=>chrome.storage.local.set({collecting:false,collectStatus:e.message}));
    }
    if(m.type==='STOP') {stop=true;reply({ok:true});}
    if(m.type==='STATE') reply({running});
  });
})();
