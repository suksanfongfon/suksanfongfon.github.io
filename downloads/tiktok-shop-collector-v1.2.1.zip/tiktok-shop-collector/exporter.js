(function (scope) {
  const headers = ['ภาพสินค้า', 'ชื่อสินค้า', 'ราคา (ตามหน้าเว็บ)', 'ยอดขาย (ตามหน้าเว็บ)', 'URL ภาพ', 'ลิงก์สินค้า', 'หน้าที่เก็บ', 'เวลาเก็บข้อมูล (ISO UTC)'];
  const safeUrl = value => /^https?:\/\/[^\s"<>]+$/i.test(String(value || '')) ? String(value) : '';
  const values = p => ['', String(p.name || ''), String(p.price || ''), String(p.sales || ''), safeUrl(p.image), safeUrl(p.url), safeUrl(p.source), String(p.collectedAt || '')];
  function csvCell(value) {
    let text = String(value ?? '');
    // A quoted CSV cell can still be interpreted as a formula by spreadsheet apps.
    if (/^[\s\uFEFF]*[=+@-]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
  }
  function csv(products) {
    // CSV stores image URLs; no image/formula column because CSV cannot embed images.
    return '\uFEFF' + [headers.slice(1), ...products.map(p => values(p).slice(1))].map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
  }
  function workbook(products, Excel) {
    const book = new Excel.Workbook();
    book.creator = 'TikTok Shop Collector';
    book.calcProperties.fullCalcOnLoad = true;
    const sheet = book.addWorksheet('TikTok Products', {views:[{state:'frozen',ySplit:1}]});
    sheet.columns = headers.map((header,i) => ({header,width:[18,48,22,24,40,40,40,28][i]}));
    sheet.autoFilter = {from:'A1',to:'H1'};
    sheet.getRow(1).height = 32;
    sheet.getRow(1).eachCell(cell => {
      cell.fill = {type:'pattern',pattern:'solid',fgColor:{argb:'FF173F4A'}};
      cell.font = {bold:true,color:{argb:'FFFFFFFF'},name:'Tahoma',size:11};
      cell.alignment = {vertical:'middle',wrapText:true};
    });
    for (const p of products) {
      const row = sheet.addRow(values(p)); row.height = 72;
      row.eachCell({includeEmpty:true},cell => {
        cell.font = {name:'Tahoma',size:11};
        cell.alignment = {vertical:'middle',wrapText:true};
      });
      if (safeUrl(p.image)) {
        // Microsoft 365 / Excel 2024 can render HTTPS images. Keep URL as fallback.
        row.getCell(1).value = /^https:\/\//i.test(p.image)
          ? {formula:`IFERROR(_xlfn.IMAGE(E${row.number},"ภาพสินค้า",0),"เปิดลิงก์ภาพในคอลัมน์ E")`,result:'เปิดลิงก์ภาพในคอลัมน์ E'}
          : 'เปิดลิงก์ภาพในคอลัมน์ E';
      }
      for (const i of [5,6,7]) {
        const url = row.getCell(i).value;
        if (url) { row.getCell(i).value = {text:url,hyperlink:url}; row.getCell(i).font = {name:'Tahoma',size:10,color:{argb:'FF14785A'},underline:true}; }
      }
    }
    return book;
  }
  function filename(extension) {
    const date = new Date();
    const pad = n => String(n).padStart(2,'0');
    return `tiktok-products-${date.getFullYear()}${pad(date.getMonth()+1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}.${extension}`;
  }
  function download(data, mime, name) {
    const blob = new Blob([data],{type:mime});
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href=url; a.download=name; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url),60000);
  }
  scope.ShopExport = {headers,csv,workbook,filename,download};
  if (typeof module !== 'undefined') module.exports=scope.ShopExport;
})(globalThis);
