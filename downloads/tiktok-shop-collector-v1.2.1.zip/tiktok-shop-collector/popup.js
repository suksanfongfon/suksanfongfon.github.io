const $ = id => document.getElementById(id);
let tabId;
async function activeShop() {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  const u = new URL(tab?.url || 'https://invalid.local');
  if (!/(^|\.)tiktok\.com$/.test(u.hostname) || u.protocol !== 'https:') throw new Error('เปิดหน้า TikTok Shop ที่มีรายการสินค้าก่อน');
  tabId = tab.id;
  await chrome.scripting.executeScript({target:{tabId},files:['extractor.js','scroller.js','content.js']});
  return tabId;
}
function render(data) {
  const products = data.products || [];
  $('count').textContent = `${products.length} รายการ`;
  const missing = products.filter(p => !p.price || !p.sales || !p.image).length;
  $('missing').textContent = missing ? `ข้อมูลไม่ครบ ${missing} รายการ` : '';
  $('status').textContent = data.collectStatus || 'พร้อมเก็บข้อมูล';
  $('exportStatus').textContent = data.exportStatus || ''; 
  $('preview').replaceChildren();
  for (const p of products.slice(0,30)) {
    const row = document.createElement('div'); row.className = 'row';
    if (/^https?:\/\//.test(p.image)) {const img = document.createElement('img'); img.src = p.image; img.alt = ''; img.referrerPolicy='no-referrer'; row.append(img);}
    const info = document.createElement('div'), name = document.createElement('strong'), detail = document.createElement('p');
    name.textContent=p.name; name.title=p.name; detail.textContent=`${p.price || 'ไม่พบราคา'} · ${p.sales || 'ไม่พบยอดขาย'}`;
    info.append(name,detail); row.append(info); $('preview').append(row);
  }
  $('csv').disabled = !products.length;
  $('excel').disabled = !products.length;
}
async function refresh() { render(await chrome.storage.local.get(['products','collectStatus','exportStatus'])); }
$('collect').onclick = async () => {
  $('collect').disabled=true;
  try {
    const limit=Number($('limit').value);
    if (!$('untilEnd').checked && (!Number.isInteger(limit) || limit<1 || limit>10000)) throw new Error('จำนวนต้องอยู่ระหว่าง 1–10000');
    const id=await activeShop();
    const result=await chrome.tabs.sendMessage(id,{type:'COLLECT',auto:$('auto').checked,limit,untilEnd:$('untilEnd').checked,autoExport:$('autoExport').checked,format:$('format').value});
    if (!result?.ok) throw new Error(result?.error || 'เริ่มเก็บไม่ได้');
  } catch(e) { $('status').textContent=e.message; }
  finally { $('collect').disabled=false; }
};
$('stop').onclick=async()=>{try { const id=await activeShop(); await chrome.tabs.sendMessage(id,{type:'STOP'}); }catch(e){$('status').textContent=e.message;} };
async function exportProducts(format) {
  const button = $(format === 'csv' ? 'csv' : 'excel');
  button.disabled = true;
  try {
    const {products = []} = await chrome.storage.local.get('products');
    if (!products.length) throw new Error('เก็บสินค้าก่อนดาวน์โหลด');
    $('exportStatus').textContent = 'กำลังเตรียมไฟล์…';
    if (format === 'csv') ShopExport.download(ShopExport.csv(products),'text/csv;charset=utf-8',ShopExport.filename('csv'));
    else {
      const book = ShopExport.workbook(products,ExcelJS);
      const buffer = await book.xlsx.writeBuffer();
      ShopExport.download(buffer,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',ShopExport.filename('xlsx'));
    }
    $('exportStatus').textContent = `เตรียมไฟล์ ${format === 'csv' ? 'CSV' : 'Excel'} แล้ว · ${products.length} รายการ — ดูในรายการดาวน์โหลดของ Chrome`;
  } catch(e) { $('exportStatus').textContent=e.message; }
  finally { button.disabled=false; }
}
$('csv').onclick=()=>exportProducts('csv');
$('excel').onclick=()=>exportProducts('xlsx');
$('untilEnd').onchange=()=>{$('limit').disabled=$('untilEnd').checked;};
$('untilEnd').onchange();
chrome.storage.onChanged.addListener(refresh);
(async()=>{
  await chrome.storage.local.remove(['endpoint','token','sheetUrl','sendStatus']);
  await refresh();
})().catch(e=>{$('status').textContent=e.message;});
