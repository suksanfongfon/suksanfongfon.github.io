(function(scope) {
  function target(doc) {
    const counts = new Map();
    for (const a of doc.querySelectorAll('a[href]')) {
      if (!scope.ShopExtractor.productUrl(a.getAttribute('href'),doc.location.href)) continue;
      for (let p=a.parentElement;p && p!==doc.body;p=p.parentElement) {
        if (p.scrollHeight <= p.clientHeight+4 || p.clientHeight<100) continue;
        if (!/auto|scroll|overlay/.test(doc.defaultView.getComputedStyle(p).overflowY)) continue;
        counts.set(p,(counts.get(p)||0)+1);
      }
    }
    return [...counts].sort((a,b)=>b[1]-a[1])[0]?.[0] || doc.scrollingElement || doc.documentElement;
  }
  function atEnd(el) { return el.scrollTop+el.clientHeight >= el.scrollHeight-6; }
  function step(el) {
    const before=el.scrollTop;
    el.scrollTo({top:before+Math.max(250,el.clientHeight*.8),behavior:'instant'});
    return el.scrollTop!==before;
  }
  function findMore(doc, scrollRoot) {
    const label=/^(?:view more|show more|load more|see more|ดูเพิ่มเติม|แสดงเพิ่มเติม|โหลดเพิ่มเติม|ดูสินค้าเพิ่มเติม)$/i;
    const productLinks=[...doc.querySelectorAll('a[href]')].filter(a=>scope.ShopExtractor.productUrl(a.getAttribute('href'),doc.location.href));
    const visibleLinks=productLinks.filter(a=>a.getBoundingClientRect().height>0);
    const lastBottom=Math.max(-Infinity,...visibleLinks.map(a=>a.getBoundingClientRect().bottom));
    const controls=[...doc.querySelectorAll('button,[role="button"],a')];
    const fallback=[...doc.querySelectorAll('div,span')].filter(el=>label.test((el.textContent||'').trim()) && doc.defaultView.getComputedStyle(el).cursor==='pointer');
    for(const candidate of [...controls,...fallback]) {
      if(!label.test((candidate.innerText||candidate.textContent||'').replace(/\s+/g,' ').trim())) continue;
      if(candidate.closest('header,footer,nav,[role="navigation"],article,dialog,[role="dialog"]')) continue;
      if(candidate.closest('a[href]') && scope.ShopExtractor.productUrl(candidate.closest('a[href]').getAttribute('href'),doc.location.href)) continue;
      // Only expansion controls: never navigate away via a View more link.
      if(candidate.tagName==='A') {
        const href=(candidate.getAttribute('href')||'').trim();
        if(href && href!=='#') continue;
      }
      if(scrollRoot!==doc.scrollingElement && scrollRoot!==doc.documentElement && !scrollRoot.contains(candidate)) continue;
      let region=candidate.parentElement, related=false;
      for(let i=0;region && i<5 && region!==doc.body;i++,region=region.parentElement) {
        if(productLinks.some(a=>region.contains(a))) {related=true;break;}
      }
      if(!related) continue;
      const rect=candidate.getBoundingClientRect(),style=doc.defaultView.getComputedStyle(candidate);
      if(rect.width<=0 || rect.height<=0 || style.visibility==='hidden' || style.display==='none' || style.opacity==='0') continue;
      if(rect.top<lastBottom-8 || rect.bottom<0 || rect.top>=doc.defaultView.innerHeight) continue;
      const disabled=!!candidate.disabled || candidate.getAttribute('aria-disabled')==='true' || candidate.getAttribute('aria-busy')==='true';
      return {element:candidate,disabled};
    }
    return null;
  }
  scope.ShopScroller={target,atEnd,step,findMore};
  if(typeof module!=='undefined') module.exports=scope.ShopScroller;
})(globalThis);
