/* Shared extraction helpers. No remote code or private TikTok API. */
(function (scope) {
  const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
  function productUrl(value, base) {
    try {
      const u = new URL(value, base);
      if (u.protocol !== 'https:' || !/(^|\.)tiktok\.com$/.test(u.hostname)) return '';
      if (!/\/(?:view\/product|product|pdp)\//.test(u.pathname)) return '';
      return u.origin + u.pathname.replace(/\/$/, '');
    } catch { return ''; }
  }
  function fields(text) {
    const s = String(text || '');
    const price = s.match(/(?:฿|THB\s*)\s*\d[\d,]*(?:\.\d{1,2})?(?:\s*[-–]\s*(?:฿\s*)?\d[\d,]*(?:\.\d{1,2})?)?/i);
    const sold = s.match(/(?:ขายแล้ว|ขายได้|จำหน่ายแล้ว|sold)\s*[:：]?\s*[\d,.]+\s*(?:พัน|หมื่น|แสน|ล้าน|[kKmM])?\+?(?:\s*ชิ้น)?/i)
      || s.match(/[\d,.]+\s*(?:พัน|หมื่น|แสน|ล้าน|[kKmM])?\+?\s*(?:sold|ขายแล้ว)/i);
    return {price: clean(price?.[0]), sales: clean(sold?.[0])};
  }
  function extract(doc, base) {
    const found = new Map();
    for (const a of doc.querySelectorAll('a[href]')) {
      const url = productUrl(a.getAttribute('href'), base);
      if (!url) continue;
      // Expand only while the container belongs to this one product.
      let card = a;
      for (let i = 0; i < 5 && card.parentElement; i++) {
        const parent = card.parentElement;
        if (/^(BODY|HTML|MAIN)$/.test(parent.tagName)) break;
        const links = new Set([...parent.querySelectorAll('a[href]')].map(x => productUrl(x.getAttribute('href'), base)).filter(Boolean));
        if (links.size !== 1 || (parent.innerText || '').length > 3500) break;
        card = parent;
      }
      const text = card.innerText || card.textContent || '';
      const data = fields(text);
      const img = card.querySelector('img');
      const title = card.querySelector('[data-e2e*="title"], [data-testid*="title"], h2, h3, [class*="product-title"], [class*="ProductTitle"]');
      const lines = text.split(/\n+/).map(clean).filter(Boolean);
      const name = clean(title?.textContent || a.getAttribute('title') || img?.getAttribute('alt') || lines.find(line => !fields(line).price && !fields(line).sales));
      let image = img?.currentSrc || img?.getAttribute('src') || img?.getAttribute('data-src') || '';
      try { image = new URL(image, base).href; if (!/^https?:\/\//.test(image) || !img) image = ''; } catch { image = ''; }
      if (!name || (!image && !data.price)) continue;
      const row = {name, image, ...data, url, source: base, collectedAt: new Date().toISOString()};
      const previous = found.get(url);
      if (!previous) found.set(url, row);
      else for (const k of ['name', 'image', 'price', 'sales']) if (!previous[k] && row[k]) previous[k] = row[k];
    }
    return [...found.values()];
  }
  scope.ShopExtractor = {clean, fields, productUrl, extract};
  if (typeof module !== 'undefined') module.exports = scope.ShopExtractor;
})(globalThis);
