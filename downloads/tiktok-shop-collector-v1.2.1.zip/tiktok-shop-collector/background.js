importScripts('vendor/exceljs.min.js','exporter.js');
const pending=new Set();
function base64(bytes) {
  let binary='';
  for(let i=0;i<bytes.length;i+=16384) binary+=String.fromCharCode(...bytes.subarray(i,i+16384));
  return btoa(binary);
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(m.type!=='AUTO_EXPORT') return;
  if(!sender.tab || !/^https:\/\/(?:[a-z0-9-]+\.)*tiktok\.com\//i.test(sender.tab.url || '')) return;
  if(typeof m.runId!=='string' || !m.runId || !Array.isArray(m.products) || !m.products.length || !['csv','xlsx'].includes(m.format)) {
    reply({ok:false,error:'ข้อมูลส่งออกไม่ถูกต้อง'});return;
  }
  if(pending.has(m.runId)) {reply({ok:true});return;}
  pending.add(m.runId);
  (async()=>{
    const {exportedRuns=[]}=await chrome.storage.local.get('exportedRuns');
    if(exportedRuns.includes(m.runId)) {reply({ok:true});return;}
    await chrome.storage.local.set({exportStatus:`กำลังสร้างไฟล์ ${m.format.toUpperCase()} อัตโนมัติ…`});
    const bytes=m.format==='csv' ? new TextEncoder().encode(ShopExport.csv(m.products)) : new Uint8Array(await ShopExport.workbook(m.products,ExcelJS).xlsx.writeBuffer());
    const mime=m.format==='csv'?'text/csv;charset=utf-8':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    const id=await chrome.downloads.download({url:`data:${mime};base64,${base64(bytes)}`,filename:ShopExport.filename(m.format),saveAs:false,conflictAction:'uniquify'});
    await chrome.storage.local.set({exportedRuns:[...exportedRuns,m.runId].slice(-50),autoDownloadId:id,exportStatus:`เริ่มดาวน์โหลด ${m.format.toUpperCase()} อัตโนมัติแล้ว · ${m.products.length} รายการ`});
    reply({ok:true});
  })().catch(async e=>{
    const error=`ดาวน์โหลดอัตโนมัติไม่สำเร็จ: ${e.message} — กดดาวน์โหลดเองได้`;
    await chrome.storage.local.set({exportStatus:error});reply({ok:false,error});
  }).finally(()=>pending.delete(m.runId));
  return true;
});
chrome.downloads.onChanged.addListener(async change=>{
  const {autoDownloadId}=await chrome.storage.local.get('autoDownloadId');
  if(change.id!==autoDownloadId) return;
  if(change.state?.current==='complete') await chrome.storage.local.set({exportStatus:'ดาวน์โหลดอัตโนมัติเสร็จแล้ว — ดูไฟล์ใน Downloads'});
  if(change.state?.current==='interrupted') await chrome.storage.local.set({exportStatus:'ดาวน์โหลดถูกขัดจังหวะ — กดดาวน์โหลดอีกครั้งได้'});
});
